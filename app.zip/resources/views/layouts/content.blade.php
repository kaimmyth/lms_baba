@extends('layouts.app')
@section('content')
@include($data['content'])
@endsection