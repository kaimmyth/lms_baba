@include('layout.header')
    <div class="app-main__outer">
        <div class="app-main__inner">
     
        <div class="card-body">
            hello
        </div>
    </div><!--end of main inner-->
    @include('layout.footer')