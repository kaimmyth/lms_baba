<footer class="footer">
	<Center><h6 style="color:#fff; font-weight:500;">  DC SERAIKELA © 2019 IT-SCIENT</h6></Center>
</footer>