<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\TestSeries;
use Faker\Generator as Faker;

$factory->define(TestSeries::class, function (Faker $faker) {
    return [
        //
    ];
});
