</div>

</div>

<div class="app-wrapper-footer">
    <div class="app-footer">

    </div>
</div><?php /**PATH F:\xampp\htdocs\lms_baba\resources\views/layouts/footer.blade.php ENDPATH**/ ?>