<div class="app-main__outer">
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="pe-7s-phone icon-gradient bg-night-fade">
                        </i>
                    </div>
                    <div>Course Catalogue
                        <div class="page-title-subheading">Create a brand new catalogue by assigning number of pre-existing course and allow user to view it.
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(url(('/'.Auth::user()->name.'/company/instructor/manage/course_catelog/add'))); ?>" method="post" enctype='multipart/form-data'> 
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="position-relative form-group" style="padding-left: 1em;">
                                    <label>Course</label>
                                    <select name="course_id" class="form-control" required="">
                                        <option value="">--Select Course--</option>
                                        <?php if(@$courseList): ?>
                                        <?php $__currentLoopData = $courseList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->course_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>

                                </div>
                            </div>
                            <div class="col-md-4">
                            <div class="position-relative form-group"><label for="exampleSelect" class="">Select status</label>
                                <select name="status" id="exampleSelect" class="form-control" required>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>                      
                                </select>
                            </div>
                        </div>
                        </div>
                        <div class="row">
                            <?php if(@$catalogueList): ?>
                            <?php $__currentLoopData = $catalogueList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="position-relative row form-group" style="padding-left: 2em;">
                                    <div class="position-relative form-check"><label class="form-check-label">
                                            <input id="checkbox2" name="catalog[]" type="checkbox" value="<?php echo e($value->id); ?>" class="form-check-input" ><?php echo e($value->catalogue_name); ?></label>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </div>

                        <hr class="new2">
                        <button type="submit" class="ladda-button mb-2 mr-2 btn-square btn btn-gradient-primary" data-style="expand-left">
                            <span class="ladda-label">Create</span>
                            <span class="ladda-spinner"></span>
                            <div class="ladda-progress" style="width: 0px;">
                            </div>
                        </button>

                        <button class="ladda-button mb-2 mr-2 btn-square btn btn-dashed btn-outline-dark" data-style="slide-right">
                            <span class="ladda-label">Cancel</span>
                            <span class="ladda-spinner"></span>
                            <div class="ladda-progress" style="width: 0px;">
                            </div>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <br/>
        <div class="row">
            <div class="col-md-12">
                <div class="card-body">
                    <table class="mb-0 table table-sm">
                        <thead>
                            <tr>
                                <th>SR. NO.</th>
                                <th>COURSE</th>
                                <th>CATALOGUE</th>
                                <th>STATUS</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(@$catalogList): ?>
                            <?php $__currentLoopData = $catalogList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($value->courseData->course_name); ?></td>
                                <td><?php echo e($value->catalogueData->catalogue_name); ?></td>
                                <td><?php echo e($value->catalog_status); ?></td>
                                <td>
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                    <a href="#"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                    <i class="fa fa-certificate"></i>
                                    <i class="fas fa-edit"></i>
                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="12">Data not found in our database</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div><!--end of main-inner-->
</div><?php /**PATH F:\xampp\htdocs\lms_baba\resources\views/instructor/manage/course_catelog.blade.php ENDPATH**/ ?>