<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mcq_questions extends Model
{
    
    // public $timestamps = false;
    public  $table = "mcq_questions";

}
