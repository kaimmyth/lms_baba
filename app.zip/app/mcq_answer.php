<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mcq_answer extends Model
{
    // public $timestamps = false;
    public  $table = "mcq_answer";
}
